package io.swagger.client.model;

import java.util.Objects;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import com.google.gson.annotations.SerializedName;




@ApiModel(description = "")
public class Utterance   {
  
  @SerializedName("utterance")
  private String utterance = null;
  

  
  /**
   **/
  @ApiModelProperty(value = "")
  public String getUtterance() {
    return utterance;
  }
  public void setUtterance(String utterance) {
    this.utterance = utterance;
  }

  

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Utterance utterance = (Utterance) o;
    return Objects.equals(utterance, utterance.utterance);
  }

  @Override
  public int hashCode() {
    return Objects.hash(utterance);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Utterance {\n");
    
    sb.append("    utterance: ").append(toIndentedString(utterance)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
