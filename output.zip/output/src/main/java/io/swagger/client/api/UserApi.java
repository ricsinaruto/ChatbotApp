package io.swagger.client.api;

import io.swagger.client.CollectionFormats.*;


import retrofit2.Call;
import retrofit2.http.*;

import okhttp3.RequestBody;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public interface UserApi {
  
  /**
   * User changes the name of the chatbot
   * 
   * @param username The user name
   * @param chatbotName The chatbot name specified by user
   * @return Call<String>
   */
  
  @GET("user/chatbotName")
  Call<String> changeChatbotName(
    @Query("username") String username, @Query("chatbotName") String chatbotName
  );

  
  /**
   * Login existing user
   * 
   * @param username The user name for login
   * @param password The password for login in clear text
   * @return Call<String>
   */
  
  @GET("user/login")
  Call<String> loginUser(
    @Query("username") String username, @Query("password") String password
  );

  
  /**
   * Register new user
   * 
   * @param username The user name
   * @param password The choosen password in clear text
   * @return Call<String>
   */
  
  @GET("user/register")
  Call<String> registerUser(
    @Query("username") String username, @Query("password") String password
  );

  
}
