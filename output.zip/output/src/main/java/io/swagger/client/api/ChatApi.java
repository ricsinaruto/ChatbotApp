package io.swagger.client.api;

import io.swagger.client.CollectionFormats.*;


import retrofit2.Call;
import retrofit2.http.*;

import okhttp3.RequestBody;

import io.swagger.client.model.Chat;
import io.swagger.client.model.Utterance;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public interface ChatApi {
  
  /**
   * Get chatbot name and all chat data for current user
   * 
   * @param username The user name
   * @return Call<Chat>
   */
  
  @GET("chat")
  Call<Chat> getChat(
    @Path("username") String username
  );

  
  /**
   * Send a message to the server
   * 
   * @param body Utterance that we need a response to
   * @return Call<Utterance>
   */
  
  @POST("chat/message")
  Call<Utterance> sendMessage(
    @Body Utterance body
  );

  
}
